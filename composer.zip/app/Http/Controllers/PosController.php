<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleDetail;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Support\Facades\Auth;

class PosController extends Controller
{
    // ... (fungsi index, checkProduct, search tetap sama) ...
    public function index() { 
        // Anda mungkin perlu membuat view 'cashier.pos' jika belum ada
        // Untuk sekarang, kita asumsikan file itu ada
        return view('cashier.pos'); 
    }
    
    public function checkProduct(Request $request) {
        $product = Product::where('barcode', $request->barcode)->first();
        if ($product) {
            return response()->json($product);
        }
        return response()->json(['error' => 'Produk tidak ditemukan'], 404);
    }

    public function search(Request $request) {
        $products = Product::where('name', 'like', '%' . $request->query('query') . '%')
            ->where('stock', '>', 0)
            ->take(10)
            ->get();
        return response()->json($products);
    }

    /**
     * Memproses pembayaran dari halaman POS.
     */
    public function store(Request $request)
    {
        // Validasi data yang masuk dari frontend
        $request->validate([
            'items' => 'required|array|min:1',
            'items.*.id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'total' => 'required|numeric',
            'payment_method' => 'required|string', // Kolom ini ada di tabel sales Anda
        ]);

        try {
            DB::beginTransaction();

            // 1. Simpan data penjualan ke tabel 'sales'
            $sale = Sale::create([
                'user_id' => Auth::id(), // Sesuai dengan tabel Anda
                'total_amount' => $request->total,
                'payment_method' => $request->payment_method, // Sesuai dengan tabel Anda
            ]);

            // 2. Simpan setiap item ke 'sale_details' dan kurangi stok produk
            foreach ($request->items as $item) {
                $product = Product::find($item['id']);
                if ($product->stock < $item['quantity']) {
                    throw new \Exception('Stok produk ' . $product->name . ' tidak mencukupi.');
                }

                SaleDetail::create([
                    'sale_id' => $sale->id,
                    'product_id' => $item['id'],
                    'quantity' => $item['quantity'],
                    'price_at_transaction' => $product->price, // Sesuai nama kolom di database Anda
                    'discount_at_transaction' => $product->discount_percent ?? 0, // Sesuai nama kolom di database Anda
                ]);

                // Kurangi stok produk
                $product->decrement('stock', $item['quantity']);
            }

            DB::commit();

            // Jika berhasil, kirim response sukses dengan ID penjualan
            return response()->json([
                'success' => true,
                'message' => 'Pembayaran berhasil diproses!',
                'sale_id' => $sale->id
            ]);

        } catch (\Exception $e) {
            DB::rollBack();
            // Jika gagal, kirim response error
            return response()->json(['success' => false, 'message' => $e->getMessage()], 500);
        }
    }

    /**
     * Menghasilkan dan menampilkan struk PDF.
     */
    public function generateReceipt($sale_id)
    {
        // Kita tidak lagi memuat relasi 'customer' karena tidak ada di tabel sales
        $sale = Sale::with('details.product')->findOrFail($sale_id);

        $pdf = PDF::loadView('receipts.pdf', compact('sale'));
        
        $pdf->setPaper([0, 0, 226.77, 600]);

        return $pdf->stream('struk-' . $sale->id . '.pdf');
    }
}
