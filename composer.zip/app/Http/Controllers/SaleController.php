<?php

namespace App\Http\Controllers\Cashier;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\Sale;
use App\Models\SaleDetail;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Barryvdh\DomPDF\Facade\Pdf;

class SaleController extends Controller
{
    public function index()
    {
        return view('cashier.pos');
    }

    public function checkProductByBarcode(Request $request)
    {
        $product = Product::where('barcode', $request->barcode)->first();

        if ($product) {
            if ($product->stock > 0) {
                return response()->json($product);
            }
            return response()->json(['error' => 'Stok produk habis!'], 404);
        }
        return response()->json(['error' => 'Produk tidak ditemukan!'], 404);
    }

    public function searchProductByName(Request $request)
    {
        $query = $request->get('query');
        if (!$query) {
            return response()->json([]);
        }

        $products = Product::where('name', 'LIKE', "%{$query}%")
                            ->where('stock', '>', 0)
                            ->limit(5)
                            ->get();

        return response()->json($products);
    }

    public function store(Request $request)
    {
        $request->validate([
            'items' => 'required|array|min:1',
            'items.*.id' => 'required|exists:products,id',
            'items.*.quantity' => 'required|integer|min:1',
            'payment_method' => 'required|in:cash,qris',
            'total' => 'required|numeric'
        ]);

        DB::beginTransaction();
        try {
            // PERBAIKAN UTAMA ADA DI SINI
            $sale = Sale::create([
                'user_id' => Auth::id(), // Menambahkan ID kasir yang sedang login
                'total_amount' => $request->total,
                'payment_method' => $request->payment_method,
            ]);

            foreach ($request->items as $item) {
                $product = Product::find($item['id']);
                if ($product->stock < $item['quantity']) {
                    throw new \Exception('Stok produk ' . $product->name . ' tidak mencukupi.');
                }

                $sale->details()->create([
                    'product_id' => $product->id,
                    'quantity' => $item['quantity'],
                    'price_at_transaction' => $product->price,
                    'discount_at_transaction' => $product->discount_percent,
                ]);

                $product->decrement('stock', $item['quantity']);
            }

            DB::commit();
            return response()->json(['success' => 'Transaksi berhasil disimpan!', 'sale_id' => $sale->id]);

        } catch (\Exception $e) {
            DB::rollBack();
            return response()->json(['error' => 'Transaksi gagal: ' . $e->getMessage()], 500);
        }
    }

    public function generateReceipt($sale_id)
    {
        $sale = Sale::with('details.product', 'user')->findOrFail($sale_id);
        $pdf = PDF::loadView('receipts.pdf', compact('sale'));
        $pdf->setPaper([0, 0, 226.77, 600]);
        return $pdf->stream('struk-' . $sale->id . '.pdf');
    }
}
